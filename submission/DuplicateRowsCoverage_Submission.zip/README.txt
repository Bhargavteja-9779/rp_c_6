DuplicateRowsCoverage submission package
Journal: Journal of King Saud University - Computer and Information Sciences (Springer Nature)
Article type: regular research article. Review model: double-anonymous.

Files and where they go in Editorial Manager
-------------------------------------------
1_Main_Manuscript.pdf               Manuscript (anonymized; contains no author information).
2_Supplementary_Material.pdf        Supplementary material (proofs, per-data-set tables, deviation log).
3_Cover_Letter.docx / .pdf          Cover letter.
4_Main_Manuscript_Word_version.docx Editable manuscript, if the system asks for an editable file.
5_LaTeX_Source.zip                  LaTeX source (Springer sn-jnl template). Compiles stand-alone:
                                    unzip, then run "bash build.sh" (pdflatex + bibtex). Tested.
6_Title_Page.docx                   Title page with author details (upload separately; kept out of the
                                    anonymized manuscript).

What the authors must still do before submitting
-----------------------------------------------
1. Fill in 6_Title_Page.docx: authors, affiliations, corresponding author, e-mail, ORCID.
2. Complete Funding, Competing interests and Author contributions in the Declarations
   (paper/sections/declarations.tex), then rebuild with paper/build.sh.
3. Archive the code repository and data cache with a DOI (e.g. Zenodo) and insert the link in the
   Code availability statement and the cover letter. Provide an anonymized link for review.
4. Confirm the AI-use statement against the journal's current policy. All authors must read and
   approve the manuscript and take responsibility for it.
5. Date and sign the cover letter, and confirm that the work is original and not under review
   elsewhere.
6. Check the journal's current page and format requirements in Editorial Manager.

Everything in the manuscript is generated from the result files in the repository
(code/run_all.py --mode full rebuilds all experiments, numbers, tables, figures and documents).
